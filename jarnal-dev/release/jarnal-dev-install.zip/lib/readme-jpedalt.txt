The file jpedalT.jar in this directory is identical with the GPL
version downloadable jpedal.jar from 11.11.2004, with the exception
that PdfDecoder.class has been replaced by a bug-fixed variant
generated from the corresponding 14_os_jpedal.src.zip.

The bug fix is a single place in method getPageAsImage.

Gunnar Teege, 27.12.2004
